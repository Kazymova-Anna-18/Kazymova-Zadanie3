﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Задание3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int max = 0;
            int polzov = 0;
            int poradok = 0;
            int[] a = new int[970];
            string element;
            StreamReader vaile = new StreamReader("E:\\задача3.txt"); //Чтение элементов из файла
            while (!vaile.EndOfStream) //Пока переменная не равна конечному значению выполнять массив
            {
                listBox1.Items.Add(vaile.ReadLine() + "\r\n"); //Вывод элементов в ListBox1
            }
            vaile.Close(); //Закрытие чтения
            StreamReader sr = new StreamReader("E:\\задача3.txt"); //Чтение элементов из файла
            element = sr.ReadLine();

            while (element != null)
            {
                for (int i = 1; i < a.Length; i++)//Начинаем перебор со второй строчки
                {
                    a[i] = Convert.ToInt32(sr.ReadLine());// Присваеваем элемент
                    for (int j=1;j<10;j++)//Элементы с 1 до 9
                    {
                        if (a[i] == j)//Ограничиваем 
                        {
                            if (poradok <= 8200)
                            {
                                polzov++;//Подсчет количества людей
                                poradok += a[i];//Сколько место будет занято
                                if (max < a[i])
                                {
                                    max = a[i];//Максимальное число
                                }
                            }
                        }
                    }
                    for (int j = 10; j < 20; j++)//Элементы с 10 до 19
                    {
                        if (a[i] == j)//Ограничиваем 
                        {
                            if (poradok <= 8200)
                            {
                                polzov++;//Подсчет количества людей
                                poradok += a[i];
                                if (max < a[i])
                                {
                                    max = a[i];//Максимальное число
                                }
                            }
                        }
                    }
                    for (int j = 20; j < 30; j++)
                    {
                        if (a[i] == j)
                        {
                            if (poradok <= 8200)
                            {
                                polzov++;
                                poradok += a[i];
                                if (max < a[i])
                                {
                                    max = a[i];
                                }
                            }
                        }
                    }
                    for (int j = 30; j < 40; j++)
                    {
                        if (a[i] == j)
                        {
                            if (poradok <= 8200)
                            {
                                polzov++;
                                poradok += a[i];
                                if (max < a[i])
                                {
                                    max = a[i];
                                }
                            }
                        }
                    }
                    for (int j = 40; j < 50; j++)
                    {
                        if (a[i] == j)
                        {
                            if (poradok <= 8200)
                            {
                                polzov++;
                                poradok += a[i];
                                if (max < a[i])
                                {
                                    max = a[i];
                                }
                            }
                        }
                    }
                    for (int j = 50; j < 60; j++)
                    {
                        if (a[i] == j)
                        {
                            if (poradok <= 8200)
                            {
                                polzov++;
                                poradok += a[i];
                                if (max < a[i])
                                {
                                    max = a[i];
                                }
                            }
                        }
                    }
                    for (int j = 60; j < 70; j++)
                    {
                        if (a[i] == j)
                        {
                            if (poradok <= 8200)
                            {
                                polzov++;
                                poradok += a[i];
                                if (max < a[i])
                                {
                                    max = a[i];
                                }
                            }
                        }
                    }
                    for (int j = 70; j < 80; j++)
                    {
                        if (a[i] == j)
                        {
                            if (poradok <= 8200)
                            {
                                polzov++;
                                poradok += a[i];
                                if (max < a[i])
                                {
                                    max = a[i];
                                }
                            }
                        }
                    }
                    for (int j = 80; j < 90; j++)
                    {
                        if (a[i] == j)
                        {
                            if (poradok <= 8200)
                            {
                                polzov++;
                                poradok += a[i];
                                if (max < a[i])
                                {
                                    max = a[i];
                                }
                            }
                        }
                    }
                    for (int j = 90; j <= 100; j++)
                    {
                        if (a[i] == j)
                        {
                            if (poradok <= 8200)
                            {
                                polzov++;
                                poradok += a[i];
                                if (max < a[i])
                                {
                                    max = a[i];
                                }
                            }
                        }
                    }
                    
                }
                    element = sr.ReadLine();
            }
                textBox3.Text = Convert.ToString(polzov);//Вывод значения пользователей
            while (element != null)
            {
                for (int i = 1; i < a.Length; i++)
                {
                    a[i] = Convert.ToInt32(sr.ReadLine());
                    poradok -= max;//Избавляемся от самого большого элемента
                    if (a[i] >= max & poradok + a[i] <= 8200)//Сравниваем, чтоб последуюющие элементы были больше максимального, а так же, чтоб в сумме с другими он не выходил за диапозон свободного места
                    {
                        max = a[i];//Присваеваем максимальному значению данный элемент
                    }

                }
                element = sr.ReadLine();
            }
            textBox1.Text = Convert.ToString(max);//Вывод максимального значения
        }
    }
}

